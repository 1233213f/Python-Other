# python自动办公
## 报表合并
* pip install xlrd
* pip install xlwt
* pip install xlutils

## 批量生成合同
* pip install openpyxl
* pip install python-docx
* pip install docx

## 自动生成微信账单
* pip install pandas

## word批量转pdf
* pip install pywin32
