 
1、 本应用适合itop经常提交，并且重复的工作
2、 主要适用于巡检提交，或者相同频繁事件提交


优点： 解放双手，更适合把注意力集中到事件问题上、缩短办公时间


环境：python 3.7.5

使用：下载包解压后，执行itopReptile\venv\Scripts\activate.bat 返回上一层，执行 Include\py itoptile.py


说明：第一次使用需要修改的参数有：包含全局变量里面的内容，还必须注意  subserviceValueID参数(子服务的 option[@value='110' 需和源码对照，做相应的更改

qq 3065247979
