# excel自动提取工具

用于常见工作场景，自动化提取excel。

当前功能：

- 提取xls内部的特点列

## FastAPI说明

运行：

`uvicorn run:app --reload`

在线查看api

`http://127.0.0.1:8000/docs`



## TODO

- 解决部分xls文件读取报错问题

