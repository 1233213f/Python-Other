import log
log.info('666')
print(666)
