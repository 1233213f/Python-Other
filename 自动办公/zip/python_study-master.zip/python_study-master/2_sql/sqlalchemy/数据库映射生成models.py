# -*- coding: utf-8 -*-
# @Time : 2020/3/13 15:42
# @Author : lzf
# @File : 数据库映射生成models.py
# @Software: PyCharm
# @Description:


#sqlserver sqlacodegen mssql+pymssql://sa:123@127.0.0.1:1433/dbname > models.py
#mysql sqlacodegen mysql://root:root@120.79.46.152:3306/datav > db_models.py